function sendMail(params){
    
    var temParams = {
        name:document.getElementById("name").value,
        email:document.getElementById("email").value,
        contact:document.getElementById("contact").value,
        message:document.getElementById("msg").value,
    };
 
    emailjs.sendForm('service_kuwjfhh','template_tpkng4o',temParams)
    .then(function(res){
        console.log("success",res.status);
    
    })
   

      document.getElementById("myButton").onclick = function () {
        location.href = "./thank.html";
    };
 
 
 }
